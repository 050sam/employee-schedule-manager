import React, { useState, useEffect } from 'react';
import { ScheduleTable } from '@/components/ScheduleTable';
import { Statistics } from '@/components/Statistics';
import { AddEmployeeDialog } from '@/components/AddEmployeeDialog';
import { ExcelUploader } from '@/components/ExcelUploader';
import { Dashboard } from '@/components/Dashboard';
import { Button } from '@/components/ui/button';
import { Download, RotateCcw, Menu, X, Save } from 'lucide-react';
import { toast } from 'sonner';

interface Employee {
  id: number;
  name: string;
  position: string;
  schedule: Record<string, string>;
}

interface DataType {
  employees: Employee[];
  legend: Record<string, string>;
  month: string;
}

export default function Home() {
  const [data, setData] = useState<DataType | null>(null);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showUploader, setShowUploader] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    const loadData = async () => {
      try {
        const response = await fetch('/data.json');
        if (!response.ok) throw new Error('Failed to load data');
        const jsonData = await response.json();
        setData(jsonData);
        setLoading(false);
      } catch (error) {
        console.error('Error loading data:', error);
        setLoading(false);
      }
    };

    loadData();
  }, []);

  const handleExcelUpload = (employees: Employee[], legend: Record<string, string>) => {
    setData({
      employees,
      legend,
      month: 'مايو 2026',
    });
    setShowUploader(false);
    setSelectedEmployee(null);
    setHasChanges(true);
    toast.success('تم استبدال البيانات بنجاح');
  };

  const handleScheduleChange = (employeeId: number, day: string, value: string) => {
    setData((prevData) => {
      if (!prevData) return prevData;
      const updatedEmployees = prevData.employees.map((emp) =>
        emp.id === employeeId
          ? {
              ...emp,
              schedule: {
                ...emp.schedule,
                [day]: value,
              },
            }
          : emp
      );
      return { ...prevData, employees: updatedEmployees };
    });

    if (selectedEmployee?.id === employeeId) {
      setSelectedEmployee((prev) =>
        prev
          ? {
              ...prev,
              schedule: {
                ...prev.schedule,
                [day]: value,
              },
            }
          : prev
      );
    }

    setHasChanges(true);
  };

  const handleAddEmployee = (name: string, position: string) => {
    setData((prevData) => {
      if (!prevData) return prevData;
      const newId = Math.max(...prevData.employees.map((e) => e.id), 0) + 1;
      const newSchedule: Record<string, string> = {};
      for (let i = 1; i <= 31; i++) {
        newSchedule[i.toString()] = 'P';
      }
      const newEmployee: Employee = {
        id: newId,
        name,
        position,
        schedule: newSchedule,
      };
      return {
        ...prevData,
        employees: [...prevData.employees, newEmployee],
      };
    });
    setHasChanges(true);
    toast.success('تم إضافة الموظف بنجاح');
  };

  const handleDeleteEmployee = (employeeId: number) => {
    setData((prevData) => {
      if (!prevData) return prevData;
      return {
        ...prevData,
        employees: prevData.employees.filter((emp) => emp.id !== employeeId),
      };
    });
    if (selectedEmployee?.id === employeeId) {
      setSelectedEmployee(null);
    }
    setHasChanges(true);
  };

  const handleEditEmployee = (updatedEmployee: Employee) => {
    setData((prevData) => {
      if (!prevData) return prevData;
      return {
        ...prevData,
        employees: prevData.employees.map((emp) =>
          emp.id === updatedEmployee.id ? updatedEmployee : emp
        ),
      };
    });
    setSelectedEmployee(updatedEmployee);
    setHasChanges(true);
  };

  const handleSaveData = async () => {
    if (!data) return;

    setIsSaving(true);
    try {
      const response = await fetch('/api/schedule/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          employees: data.employees,
          month: data.month,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to save data');
      }

      setHasChanges(false);
      toast.success('تم حفظ البيانات بنجاح في قاعدة البيانات');
    } catch (error) {
      console.error('Error saving data:', error);
      toast.error('فشل حفظ البيانات. تحقق من الاتصال.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleExportData = () => {
    const dataStr = JSON.stringify(data, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `schedule-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    toast.success('تم تصدير البيانات بنجاح');
  };

  const handleResetData = () => {
    if (window.confirm('هل أنت متأكد من رغبتك في إعادة تعيين جميع البيانات؟')) {
      window.location.reload();
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block">
            <div className="w-16 h-16 border-4 border-primary/20 border-t-primary rounded-full animate-spin"></div>
          </div>
          <p className="mt-6 text-primary font-semibold text-lg">جاري تحميل البيانات...</p>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 flex items-center justify-center p-4">
        <div className="text-center max-w-md">
          <div className="mb-6">
            <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto">
              <X className="text-red-600" size={40} />
            </div>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">حدث خطأ</h2>
          <p className="text-gray-600 mb-6">لم يتمكن من تحميل البيانات. يرجى إعادة تحميل الصفحة أو رفع ملف إكسل.</p>
          <Button
            onClick={() => window.location.reload()}
            className="bg-primary hover:bg-primary/90 text-white"
          >
            إعادة تحميل
          </Button>
        </div>
      </div>
    );
  }

  const calculateStats = () => {
    let totalPresent = 0;
    let totalAbsent = 0;
    let totalDays = 0;

    data.employees.forEach((emp) => {
      Object.values(emp.schedule).forEach((status) => {
        if (status === 'P') totalPresent++;
        if (status === 'A') totalAbsent++;
        totalDays++;
      });
    });

    const averageAttendance = Math.round((totalPresent / totalDays) * 100);

    return { totalPresent, totalAbsent, averageAttendance };
  };

  const stats = calculateStats();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-xl border-b border-gray-200/50 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="lg:hidden p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
                  مدير جدول الموظفين
                </h1>
                <p className="text-gray-600 mt-1 font-medium">{data.month}</p>
              </div>
            </div>
            <div className="flex gap-2 flex-wrap">
              {hasChanges && (
                <Button
                  onClick={handleSaveData}
                  disabled={isSaving}
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white"
                >
                  <Save size={18} />
                  {isSaving ? 'جاري الحفظ...' : 'حفظ التعديلات'}
                </Button>
              )}
              <Button
                onClick={() => setShowUploader(!showUploader)}
                variant="outline"
                className="flex items-center gap-2 border-primary/30 text-primary hover:bg-primary/5"
              >
                <Download size={18} />
                رفع إكسل
              </Button>
              <Button
                onClick={handleExportData}
                variant="outline"
                className="flex items-center gap-2"
              >
                <Download size={18} />
                تصدير
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Upload Section */}
      {showUploader && (
        <div className="bg-white/50 backdrop-blur-sm border-b border-gray-200/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="max-w-2xl">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">استبدال البيانات</h3>
              <ExcelUploader onDataLoaded={handleExcelUpload} />
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard Stats */}
        <Dashboard
          totalEmployees={data.employees.length}
          totalPresent={stats.totalPresent}
          totalAbsent={stats.totalAbsent}
          averageAttendance={stats.averageAttendance}
        />

        {/* Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Table Section */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <ScheduleTable
                employees={data.employees}
                legend={data.legend}
                onEmployeeSelect={setSelectedEmployee}
                onScheduleChange={handleScheduleChange}
                onAddEmployee={() => setIsAddDialogOpen(true)}
                onDeleteEmployee={handleDeleteEmployee}
                onEditEmployee={handleEditEmployee}
                selectedEmployee={selectedEmployee}
              />
            </div>
          </div>

          {/* Statistics Section */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <div className="bg-white rounded-2xl shadow-lg p-6">
                <h2 className="text-2xl font-bold text-primary mb-6">الإحصائيات</h2>
                <Statistics
                  selectedEmployee={selectedEmployee}
                  legend={data.legend}
                />
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Legend Section */}
      <section className="bg-white/80 backdrop-blur-xl border-t border-gray-200/50 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <h3 className="text-lg font-bold text-primary mb-6">المفاتيح والرموز</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
            {Object.entries(data.legend).map(([key, value]) => {
              const colorMap: Record<string, string> = {
                P: 'bg-green-100 text-green-800 border-green-300',
                'D/O': 'bg-orange-100 text-orange-800 border-orange-300',
                'E/H': 'bg-yellow-100 text-yellow-800 border-yellow-300',
                A: 'bg-red-100 text-red-800 border-red-300',
                T: 'bg-blue-100 text-blue-800 border-blue-300',
                S: 'bg-purple-100 text-purple-800 border-purple-300',
              };
              return (
                <div key={key} className="text-center">
                  <div
                    className={`px-3 py-2 rounded-lg border-2 font-bold mb-2 inline-block ${
                      colorMap[key]
                    }`}
                  >
                    {key}
                  </div>
                  <p className="text-sm text-gray-600 font-medium">{value}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Dialogs */}
      <AddEmployeeDialog
        isOpen={isAddDialogOpen}
        onClose={() => setIsAddDialogOpen(false)}
        onAdd={handleAddEmployee}
      />
    </div>
  );
}
