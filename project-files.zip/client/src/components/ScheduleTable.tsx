import React, { useState } from 'react';
import { ChevronDown, Plus, Trash2, Edit2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';

interface Employee {
  id: number;
  name: string;
  position: string;
  schedule: Record<string, string>;
}

interface ScheduleTableProps {
  employees: Employee[];
  legend: Record<string, string>;
  onEmployeeSelect: (employee: Employee | null) => void;
  onScheduleChange: (employeeId: number, day: string, value: string) => void;
  onAddEmployee: () => void;
  onDeleteEmployee: (employeeId: number) => void;
  onEditEmployee: (employee: Employee) => void;
  selectedEmployee: Employee | null;
}

const getStatusColor = (status: string): string => {
  switch (status) {
    case 'P':
      return 'bg-green-100 text-green-800 border-green-300';
    case 'D/O':
      return 'bg-orange-100 text-orange-800 border-orange-300';
    case 'E/H':
      return 'bg-yellow-100 text-yellow-800 border-yellow-300';
    case 'A':
      return 'bg-red-100 text-red-800 border-red-300';
    case 'T':
      return 'bg-blue-100 text-blue-800 border-blue-300';
    case 'S':
      return 'bg-purple-100 text-purple-800 border-purple-300';
    default:
      return 'bg-gray-100 text-gray-800 border-gray-300';
  }
};

export const ScheduleTable: React.FC<ScheduleTableProps> = ({
  employees,
  legend,
  onEmployeeSelect,
  onScheduleChange,
  onAddEmployee,
  onDeleteEmployee,
  onEditEmployee,
  selectedEmployee,
}) => {
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [editName, setEditName] = useState('');
  const [editPosition, setEditPosition] = useState('');

  const handleStartEdit = (emp: Employee) => {
    setEditingEmployee(emp);
    setEditName(emp.name);
    setEditPosition(emp.position);
  };

  const handleSaveEdit = () => {
    if (editingEmployee && editName.trim()) {
      onEditEmployee({
        ...editingEmployee,
        name: editName,
        position: editPosition,
      });
      setEditingEmployee(null);
      toast.success('تم تحديث بيانات الموظف');
    }
  };

  const days = Array.from({ length: 31 }, (_, i) => i + 1);

  return (
    <div className="w-full">
      <div className="mb-6 flex justify-between items-center">
        <h2 className="text-2xl font-bold text-primary">جدول الجدول الزمني</h2>
        <Button
          onClick={onAddEmployee}
          className="bg-primary hover:bg-primary/90 text-white flex items-center gap-2"
        >
          <Plus size={18} />
          إضافة موظف
        </Button>
      </div>

      {editingEmployee && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 rounded-lg">
          <div className="bg-white p-6 rounded-lg shadow-lg max-w-md w-full mx-4">
            <h3 className="text-xl font-bold mb-4">تعديل بيانات الموظف</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">الاسم</label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">المنصب</label>
                <input
                  type="text"
                  value={editPosition}
                  onChange={(e) => setEditPosition(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <Button
                onClick={handleSaveEdit}
                className="flex-1 bg-primary hover:bg-primary/90 text-white"
              >
                حفظ
              </Button>
              <Button
                onClick={() => setEditingEmployee(null)}
                variant="outline"
                className="flex-1"
              >
                إلغاء
              </Button>
            </div>
          </div>
        </div>
      )}

      <div className="overflow-x-auto border border-gray-200 rounded-lg shadow-sm">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-gradient-to-r from-primary/10 to-primary/5 border-b border-gray-200">
              <th className="px-4 py-3 text-right font-semibold text-primary min-w-[200px]">
                الموظف
              </th>
              <th className="px-4 py-3 text-right font-semibold text-primary min-w-[120px]">
                المنصب
              </th>
              {days.map((day) => (
                <th
                  key={day}
                  className="px-2 py-3 text-center font-semibold text-primary min-w-[50px] bg-primary/5"
                >
                  {day}
                </th>
              ))}
              <th className="px-4 py-3 text-center font-semibold text-primary min-w-[100px]">
                الإجراءات
              </th>
            </tr>
          </thead>
          <tbody>
            {employees.map((employee) => (
              <tr
                key={employee.id}
                onClick={() => onEmployeeSelect(employee)}
                className={`border-b border-gray-200 hover:bg-primary/5 transition-colors cursor-pointer ${
                  selectedEmployee?.id === employee.id ? 'bg-primary/10' : ''
                }`}
              >
                <td className="px-4 py-3 font-medium text-gray-900">
                  <span className="text-primary font-semibold">{employee.name}</span>
                </td>
                <td className="px-4 py-3 text-gray-600">{employee.position}</td>
                {days.map((day) => (
                  <td key={day} className="px-2 py-3 text-center">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button
                          className={`px-2 py-1 rounded-md border-2 font-medium text-xs cursor-pointer hover:shadow-md transition-all ${
                            getStatusColor(employee.schedule[day.toString()])
                          }`}
                        >
                          {employee.schedule[day.toString()]}
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="center" className="w-40">
                        {Object.entries(legend).map(([key, value]) => (
                          <DropdownMenuItem
                            key={key}
                            onClick={() => {
                              onScheduleChange(employee.id, day.toString(), key);
                              toast.success(`تم تحديث حالة ${employee.name}`);
                            }}
                            className="cursor-pointer flex items-center gap-2"
                          >
                            <span
                              className={`w-2 h-2 rounded-full ${
                                getStatusColor(key).split(' ')[0]
                              }`}
                            />
                            <span>{value}</span>
                            <span className="text-xs text-gray-500 mr-auto">({key})</span>
                          </DropdownMenuItem>
                        ))}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                ))}
                <td className="px-4 py-3 text-center flex gap-2 justify-center">
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleStartEdit(employee);
                    }}
                    size="sm"
                    variant="outline"
                    className="text-blue-600 hover:bg-blue-50"
                  >
                    <Edit2 size={16} />
                  </Button>
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteEmployee(employee.id);
                      toast.success('تم حذف الموظف');
                    }}
                    size="sm"
                    variant="outline"
                    className="text-red-600 hover:bg-red-50"
                  >
                    <Trash2 size={16} />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
