import React from 'react';
import { Users, TrendingUp, Calendar, AlertCircle } from 'lucide-react';

interface DashboardProps {
  totalEmployees: number;
  totalPresent: number;
  totalAbsent: number;
  averageAttendance: number;
}

const StatCard: React.FC<{
  icon: React.ReactNode;
  label: string;
  value: string | number;
  subtext?: string;
  color: string;
}> = ({ icon, label, value, subtext, color }) => (
  <div className={`bg-gradient-to-br ${color} rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105`}>
    <div className="flex items-start justify-between">
      <div className="flex-1">
        <p className="text-gray-600 font-medium text-sm mb-2">{label}</p>
        <p className="text-3xl font-bold text-gray-900">{value}</p>
        {subtext && <p className="text-xs text-gray-500 mt-2">{subtext}</p>}
      </div>
      <div className="text-4xl opacity-20 ml-4">{icon}</div>
    </div>
  </div>
);

export const Dashboard: React.FC<DashboardProps> = ({
  totalEmployees,
  totalPresent,
  totalAbsent,
  averageAttendance,
}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <StatCard
        icon={<Users />}
        label="إجمالي الموظفين"
        value={totalEmployees}
        color="from-blue-100 to-blue-50"
      />
      <StatCard
        icon={<TrendingUp />}
        label="الحضور اليوم"
        value={totalPresent}
        subtext={`من ${totalEmployees}`}
        color="from-green-100 to-green-50"
      />
      <StatCard
        icon={<AlertCircle />}
        label="الغياب"
        value={totalAbsent}
        subtext="في الشهر"
        color="from-red-100 to-red-50"
      />
      <StatCard
        icon={<Calendar />}
        label="معدل الحضور"
        value={`${averageAttendance}%`}
        subtext="متوسط الشهر"
        color="from-purple-100 to-purple-50"
      />
    </div>
  );
};
