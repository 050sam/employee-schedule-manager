import React, { useRef } from 'react';
import { Upload, AlertCircle, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';

interface Employee {
  id: number;
  name: string;
  position: string;
  schedule: Record<string, string>;
}

interface ExcelUploaderProps {
  onDataLoaded: (employees: Employee[], legend: Record<string, string>) => void;
}

export const ExcelUploader: React.FC<ExcelUploaderProps> = ({ onDataLoaded }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isProcessing, setIsProcessing] = React.useState(false);

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.xlsx') && !file.name.endsWith('.xls')) {
      toast.error('يرجى اختيار ملف إكسل صحيح (.xlsx أو .xls)');
      return;
    }

    setIsProcessing(true);
    try {
      const arrayBuffer = await file.arrayBuffer();
      const workbook = XLSX.read(arrayBuffer, { type: 'array' });
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      const data = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];

      // Parse the data
      const employees: Employee[] = [];
      const legend: Record<string, string> = {
        P: 'حضور',
        'D/O': 'إجازة',
        'E/H': 'إجازة طارئة',
        A: 'غياب',
        T: 'تدريب',
        S: 'إجازة مرضية',
      };

      // Find the header row (contains employee names)
      let headerRowIndex = -1;
      for (let i = 0; i < data.length; i++) {
        if (data[i][1] && typeof data[i][1] === 'string' && data[i][1].includes('الموظف')) {
          headerRowIndex = i;
          break;
        }
      }

      // If not found, try to find by looking for a row with many cells
      if (headerRowIndex === -1) {
        for (let i = 0; i < Math.min(10, data.length); i++) {
          if (data[i].length > 20) {
            headerRowIndex = i;
            break;
          }
        }
      }

      if (headerRowIndex === -1) headerRowIndex = 4;

      // Parse employees starting from the row after header
      let employeeId = 1;
      for (let i = headerRowIndex + 1; i < data.length; i++) {
        const row = data[i];
        if (!row || !row[1] || typeof row[1] !== 'string') continue;
        if (row[1].includes('total') || row[1].includes('المفاتيح')) break;

        const name = String(row[1]).trim();
        const position = row[2] ? String(row[2]).trim() : '';

        if (name && name.length > 0) {
          const schedule: Record<string, string> = {};
          for (let day = 1; day <= 31; day++) {
            const cellValue = row[day + 2];
            schedule[day.toString()] = cellValue ? String(cellValue).trim() : 'P';
          }

          employees.push({
            id: employeeId++,
            name,
            position,
            schedule,
          });
        }
      }

      if (employees.length === 0) {
        toast.error('لم يتم العثور على بيانات موظفين في الملف');
        setIsProcessing(false);
        return;
      }

      onDataLoaded(employees, legend);
      toast.success(`تم تحميل ${employees.length} موظف بنجاح`);
    } catch (error) {
      console.error('Error processing file:', error);
      toast.error('حدث خطأ في معالجة الملف');
    } finally {
      setIsProcessing(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <div className="w-full">
      <input
        ref={fileInputRef}
        type="file"
        accept=".xlsx,.xls"
        onChange={handleFileSelect}
        className="hidden"
        disabled={isProcessing}
      />

      <button
        onClick={() => fileInputRef.current?.click()}
        disabled={isProcessing}
        className="w-full px-6 py-4 border-2 border-dashed border-primary/30 rounded-xl hover:border-primary/60 hover:bg-primary/5 transition-all duration-300 flex flex-col items-center justify-center gap-3 group"
      >
        <div className="relative">
          <Upload
            size={32}
            className={`text-primary transition-all duration-300 ${
              isProcessing ? 'animate-pulse' : 'group-hover:scale-110'
            }`}
          />
        </div>
        <div className="text-center">
          <p className="font-semibold text-primary text-lg">
            {isProcessing ? 'جاري المعالجة...' : 'رفع ملف إكسل'}
          </p>
          <p className="text-sm text-gray-600 mt-1">
            اسحب الملف هنا أو انقر للاختيار
          </p>
        </div>
      </button>
    </div>
  );
};
