import React from 'react';
import { Users, CheckCircle, Calendar, AlertCircle, Briefcase, Heart } from 'lucide-react';

interface Employee {
  id: number;
  name: string;
  position: string;
  schedule: Record<string, string>;
}

interface StatisticsProps {
  selectedEmployee: Employee | null;
  legend: Record<string, string>;
}

const StatCard: React.FC<{
  icon: React.ReactNode;
  label: string;
  value: number | string;
  color: string;
}> = ({ icon, label, value, color }) => (
  <div className={`bg-gradient-to-br ${color} rounded-lg p-4 shadow-md hover:shadow-lg transition-shadow`}>
    <div className="flex items-center justify-between">
      <div>
        <p className="text-sm font-medium text-gray-600 mb-1">{label}</p>
        <p className="text-2xl font-bold text-gray-900">{value}</p>
      </div>
      <div className="text-3xl opacity-20">{icon}</div>
    </div>
  </div>
);

export const Statistics: React.FC<StatisticsProps> = ({
  selectedEmployee,
  legend,
}) => {
  if (!selectedEmployee) {
    return (
      <div className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg p-8 text-center border border-gray-200">
        <Users size={48} className="mx-auto text-gray-400 mb-3" />
        <p className="text-gray-600 font-medium">اختر موظفاً لعرض إحصائياته</p>
      </div>
    );
  }

  const stats = {
    present: 0,
    dayOff: 0,
    emergency: 0,
    absent: 0,
    training: 0,
    sick: 0,
  };

  Object.values(selectedEmployee.schedule).forEach((status) => {
    switch (status) {
      case 'P':
        stats.present++;
        break;
      case 'D/O':
        stats.dayOff++;
        break;
      case 'E/H':
        stats.emergency++;
        break;
      case 'A':
        stats.absent++;
        break;
      case 'T':
        stats.training++;
        break;
      case 'S':
        stats.sick++;
        break;
    }
  });

  const attendanceRate = (
    ((stats.present / 31) * 100).toFixed(1)
  );

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-primary/10 to-primary/5 rounded-lg p-6 border border-primary/20">
        <h3 className="text-2xl font-bold text-primary mb-2">{selectedEmployee.name}</h3>
        <p className="text-gray-600 font-medium">{selectedEmployee.position}</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <StatCard
          icon={<CheckCircle />}
          label="أيام الحضور"
          value={stats.present}
          color="from-green-100 to-green-50"
        />
        <StatCard
          icon={<Calendar />}
          label="أيام الإجازة"
          value={stats.dayOff}
          color="from-orange-100 to-orange-50"
        />
        <StatCard
          icon={<AlertCircle />}
          label="إجازات طارئة"
          value={stats.emergency}
          color="from-yellow-100 to-yellow-50"
        />
        <StatCard
          icon={<AlertCircle />}
          label="أيام الغياب"
          value={stats.absent}
          color="from-red-100 to-red-50"
        />
        <StatCard
          icon={<Briefcase />}
          label="أيام التدريب"
          value={stats.training}
          color="from-blue-100 to-blue-50"
        />
        <StatCard
          icon={<Heart />}
          label="إجازات مرضية"
          value={stats.sick}
          color="from-purple-100 to-purple-50"
        />
      </div>

      <div className="bg-gradient-to-r from-primary/10 to-primary/5 rounded-lg p-6 border border-primary/20">
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-lg font-semibold text-primary">معدل الحضور</h4>
          <span className="text-3xl font-bold text-primary">{attendanceRate}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
          <div
            className="bg-gradient-to-r from-green-400 to-green-600 h-full transition-all duration-500"
            style={{ width: `${attendanceRate}%` }}
          />
        </div>
        <p className="text-sm text-gray-600 mt-3">
          {stats.present} يوم حضور من أصل 31 يوم
        </p>
      </div>
    </div>
  );
};
