import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertSchedule, InsertUser, schedules, users } from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function saveSchedule(schedule: InsertSchedule) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot save schedule: database not available");
    return;
  }

  try {
    await db.insert(schedules).values(schedule);
  } catch (error) {
    console.error("[Database] Failed to save schedule:", error);
    throw error;
  }
}

export async function updateSchedule(id: number, schedule: Partial<InsertSchedule>) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update schedule: database not available");
    return;
  }

  try {
    await db.update(schedules).set({
      ...schedule,
      updatedAt: new Date(),
    }).where(eq(schedules.id, id));
  } catch (error) {
    console.error("[Database] Failed to update schedule:", error);
    throw error;
  }
}

export async function getSchedulesByUserId(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get schedules: database not available");
    return [];
  }

  try {
    return await db.select().from(schedules).where(eq(schedules.userId, userId));
  } catch (error) {
    console.error("[Database] Failed to get schedules:", error);
    return [];
  }
}
